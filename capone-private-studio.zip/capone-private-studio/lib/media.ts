import {Input,CustomSource,ALL_FORMATS} from "mediabunny";
import {imageSize} from "image-size";
import {runtime,database,HttpError} from "./server";
export async function uploadMedia(req:Request){
  const {BUCKET}=runtime();const mime=req.headers.get("content-type")?.split(";")[0]||"";
  if(!["image/jpeg","image/png","image/webp","video/mp4"].includes(mime))throw new HttpError(400,"仅支持 JPG、PNG、WebP 图片或 H.264 MP4 视频。");
  const kind=mime.startsWith("video")?"video":"image",max=(kind==="video"?50:10)*1024*1024;
  const size=Number(req.headers.get("content-length"));if(!Number.isSafeInteger(size)||size<=0||size>max)throw new HttpError(413,"图片不能超过10 MB，视频不能超过50 MB。");
  const id=crypto.randomUUID(),key="uploads/"+id;
  try{
    const stored=await BUCKET.put(key,req.body,{httpMetadata:{contentType:mime}});
    if(!stored||stored.size!==size)throw new HttpError(400,"上传未完成，请重试。");
    let width=0,height=0;
    if(kind==="image"){
      const object=await BUCKET.get(key);if(!object)throw new Error("missing");
      const info=imageSize(new Uint8Array(await object.arrayBuffer()));
      if((mime==="image/jpeg"&&info.type!=="jpg")||(mime==="image/png"&&info.type!=="png")||(mime==="image/webp"&&info.type!=="webp"))throw new HttpError(400,"文件内容与类型不一致。");
      width=info.width;height=info.height;
      if(info.orientation&&info.orientation>=5)[width,height]=[height,width];
    }else{
      const header=await BUCKET.get(key,{range:{offset:0,length:16}});
      const bytes=new Uint8Array(await header!.arrayBuffer());
      if(String.fromCharCode(...bytes.slice(4,8))!=="ftyp")throw new HttpError(400,"请上传有效的 MP4 文件。");
      const source=new CustomSource({getSize:()=>size,maxCacheSize:1024*1024,read:async(start,end)=>{
        if(end-start>4*1024*1024)throw new Error("metadata too large");
        const part=await BUCKET.get(key,{range:{offset:start,length:end-start}});
        if(!part)throw new Error("missing");return new Uint8Array(await part.arrayBuffer());
      }});
      const input=new Input({source,formats:ALL_FORMATS});
      try{const track=await input.getPrimaryVideoTrack();if(!track||track.codec!=="avc")throw new HttpError(400,"视频请使用兼容手机播放的 H.264 MP4 格式。");width=track.displayWidth;height=track.displayHeight;const audio=await input.getPrimaryAudioTrack();if(audio&&audio.codec!=="aac"&&audio.codec!=="mp3")throw new HttpError(400,"视频音轨请使用 AAC 格式。");}finally{input.dispose()}
    }
    const ratio=width/height;
    if(!Number.isFinite(ratio)||width<90||height<90||width>8192||height>8192||Math.min(Math.abs(ratio/(16/9)-1),Math.abs(ratio/(9/16)-1))>.01)throw new HttpError(400,"媒体画幅必须为16:9或9:16，请调整后上传。");
    await database().prepare("INSERT INTO media (id,storageKey,mime,kind,width,height,size,createdAt) VALUES (?,?,?,?,?,?,?,?)").bind(id,key,mime,kind,width,height,size,Date.now()).run();
    return {id,kind,width,height,size};
  }catch(error){await BUCKET.delete(key);if(error instanceof HttpError)throw error;throw new HttpError(400,"无法读取媒体文件，请检查格式后重试。")}
}
export async function serveMedia(req:Request,id:string,owner:boolean){
  const m=await database().prepare("SELECT * FROM media WHERE id=?").bind(id).first<{storageKey:string;mime:string;size:number}>();
  if(!m)throw new HttpError(404,"内容不存在。");
  if(!owner&&!await database().prepare("SELECT id FROM posts WHERE mediaId=? AND status='published' LIMIT 1").bind(id).first())throw new HttpError(404,"内容不存在。");
  if(m.storageKey==="@hero")return Response.redirect(new URL("/hero.mp4",req.url),302);
  let range: {offset:number;length:number}|undefined;
  const h=new Headers({"Content-Type":m.mime,"Cache-Control":"no-store","X-Content-Type-Options":"nosniff","Accept-Ranges":"bytes"});
  const raw=req.headers.get("range");
  if(raw){const match=/^bytes=(\d*)-(\d*)$/.exec(raw);if(!match||(!match[1]&&!match[2]))return new Response(null,{status:416,headers:{"Content-Range":"bytes */"+m.size}});
    const start=match[1]?Number(match[1]):Math.max(0,m.size-Number(match[2])),end=match[1]?(match[2]?Math.min(Number(match[2]),m.size-1):m.size-1):m.size-1;
    if(start>=m.size||end<start)return new Response(null,{status:416,headers:{"Content-Range":"bytes */"+m.size}});
    range={offset:start,length:end-start+1};h.set("Content-Range","bytes "+start+"-"+end+"/"+m.size);
  }
  const object=await runtime().BUCKET.get(m.storageKey,range?{range}:undefined);if(!object)throw new HttpError(404,"文件不存在。");
  h.set("Content-Length",String(range?.length||object.size));return new Response(object.body,{status:range?206:200,headers:h});
}
